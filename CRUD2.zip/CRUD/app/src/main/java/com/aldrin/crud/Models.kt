package com.aldrin.crud

class Customer {
    var customerID : Int = 0
    var customerName : String = ""
    var maxCredit : Double = 0.0
}